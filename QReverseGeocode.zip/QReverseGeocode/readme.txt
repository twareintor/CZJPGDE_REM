Component to quick access to reverse geocode in QML.

----------

Project summary
Categories: 	
Created: 	June 1st, 2012
Visibility: 	Private
Followers:	2
Downloads: